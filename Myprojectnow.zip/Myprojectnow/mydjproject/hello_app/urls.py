from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('submit/', views.submit_name, name='submit_name'),
    path('greeting/<int:name_id>/', views.greeting, name='greeting'),
]