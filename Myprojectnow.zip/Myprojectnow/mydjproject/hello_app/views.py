from django.shortcuts import render, redirect
from django.contrib import messages
from .models import UserName

def index(request):
    """Главная страница с формой ввода имени"""
    latest_name = None
    
    # Получаем последнее сохранённое имя
    last_entry = UserName.objects.last()
    if last_entry:
        latest_name = last_entry.name
    
    return render(request, 'hello_app/index.html', {
        'latest_name': latest_name
    })

def submit_name(request):
    """Обработка формы и сохранение имени"""
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()
        
        # Валидация: проверка на пустое поле
        if not name:
            messages.error(request, 'Пожалуйста, введите ваше имя!')
            return redirect('index')
        
        # Валидация: минимальная длина
        if len(name) < 2:
            messages.error(request, 'Имя должно содержать минимум 2 символа!')
            return redirect('index')
        
        # Валидация: только буквы и пробелы
        if not all(c.isalpha() or c.isspace() for c in name):
            messages.error(request, 'Имя должно содержать только буквы!')
            return redirect('index')
        
        # Сохраняем в базу данных
        user_name = UserName.objects.create(name=name)
        
        # Перенаправляем на страницу приветствия
        return redirect('greeting', name_id=user_name.id)
    
    return redirect('index')

def greeting(request, name_id):
    """Страница с персонализированным приветствием"""
    try:
        user_name = UserName.objects.get(id=name_id)
    except UserName.DoesNotExist:
        messages.error(request, 'Запись не найдена!')
        return redirect('index')
    
    return render(request, 'hello_app/greeting.html', {
        'name': user_name.name
    })